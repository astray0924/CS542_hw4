package edu.cmu.graphchi;

/**
 * @author Aapo Kyrola
 */
public enum EdgeDirection {
    IN_EDGES, OUT_EDGES, IN_AND_OUT_EDGES
}
